"""
Number Pattern Generator - Pyramid Pattern
--------------------------------------------
This program uses nested loops to build a numeric pyramid pattern.

Example output for 5 rows:

1
1 2
1 2 3
1 2 3 4
1 2 3 4 5

The outer loop controls how many rows are printed.
The inner loop controls how many numbers appear in each row.
"""


def print_number_pyramid(rows):
    """Print a left-aligned number pyramid with the given number of rows."""
    for i in range(1, rows + 1):          # outer loop -> controls each row
        row_numbers = []
        for j in range(1, i + 1):         # inner loop -> controls numbers in the row
            row_numbers.append(str(j))
        print(" ".join(row_numbers))


def print_centered_number_pyramid(rows):
    """Print a centered number pyramid (classic pyramid shape) with spacing."""
    for i in range(1, rows + 1):
        spaces = " " * (rows - i)         # leading spaces to center the row
        numbers = " ".join(str(j) for j in range(1, i + 1))
        print(spaces + numbers)


def get_valid_rows():
    """Prompt the user for a valid positive integer number of rows."""
    while True:
        user_input = input("Enter the number of rows for the pyramid (1-20): ").strip()

        if not user_input.isdigit():
            print("Please enter a valid whole number.\n")
            continue

        rows = int(user_input)

        if rows < 1 or rows > 20:
            print("Please enter a number between 1 and 20.\n")
            continue

        return rows


def main():
    print("=" * 40)
    print("      NUMBER PYRAMID PATTERN GENERATOR")
    print("=" * 40)

    rows = get_valid_rows()

    print("\nLeft-aligned pyramid:\n")
    print_number_pyramid(rows)

    print("\nCentered pyramid:\n")
    print_centered_number_pyramid(rows)


if __name__ == "__main__":
    main()
