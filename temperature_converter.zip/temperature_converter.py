"""
Temperature Converter
-----------------------
A program that converts temperatures between Fahrenheit and Celsius,
letting the user choose the input value and the conversion direction.

Formulas used:
    Celsius to Fahrenheit:  F = (C * 9/5) + 32
    Fahrenheit to Celsius:  C = (F - 32) * 5/9
"""


def celsius_to_fahrenheit(celsius):
    """Convert a Celsius temperature to Fahrenheit."""
    return (celsius * 9 / 5) + 32


def fahrenheit_to_celsius(fahrenheit):
    """Convert a Fahrenheit temperature to Celsius."""
    return (fahrenheit - 32) * 5 / 9


def get_valid_float(prompt):
    """Prompt the user until they enter a valid number (int or float, including negatives)."""
    while True:
        user_input = input(prompt).strip()
        try:
            return float(user_input)
        except ValueError:
            print("Please enter a valid number (e.g., 72, -10, 36.6).\n")


def get_conversion_choice():
    """Ask the user which conversion direction they want."""
    print("Choose a conversion direction:")
    print("1. Celsius to Fahrenheit (C -> F)")
    print("2. Fahrenheit to Celsius (F -> C)")

    while True:
        choice = input("Enter 1 or 2: ").strip()
        if choice == "1" or choice == "2":
            return choice
        else:
            print("Invalid choice. Please enter 1 or 2.\n")


def convert_temperature(choice, value):
    """Perform the conversion based on the user's chosen direction."""
    if choice == "1":
        result = celsius_to_fahrenheit(value)
        return result, f"{value}°C is equal to {result:.2f}°F"
    elif choice == "2":
        result = fahrenheit_to_celsius(value)
        return result, f"{value}°F is equal to {result:.2f}°C"


def main():
    print("=" * 40)
    print("        TEMPERATURE CONVERTER")
    print("=" * 40)

    while True:
        choice = get_conversion_choice()

        if choice == "1":
            value = get_valid_float("Enter the temperature in Celsius: ")
        else:
            value = get_valid_float("Enter the temperature in Fahrenheit: ")

        _, message = convert_temperature(choice, value)
        print(f"\n{message}\n")

        again = input("Convert another temperature? (y/n): ").strip().lower()
        if again == "y":
            print("\n" + "-" * 40 + "\n")
            continue
        elif again == "n":
            print("\nThanks for using the Temperature Converter. Goodbye!")
            break
        else:
            print("Invalid input, exiting the program.")
            break


if __name__ == "__main__":
    main()
