"""
Task Manager CRUD Application with File Persistence
------------------------------------------------------
A Create/Read/Update/Delete task manager that persists its data to a
plain text file (tasks.txt) so tasks survive between program runs.

File format (pipe-delimited, one task per line):
    id|status|title

Example line:
    1|pending|Buy groceries

Design notes:
- Tasks are loaded from tasks.txt into memory when the program starts.
- Every Create/Update/Delete operation immediately saves the in-memory
  task list back to tasks.txt, so the file is always kept in sync.
- All file operations are wrapped in try/except blocks so problems
  like a missing file, a locked file, or bad permissions don't crash
  the program.
"""

import os

DATA_FILE = "tasks.txt"


# ---------------------------------------------------------------------------
# File I/O (Persistence Layer)
# ---------------------------------------------------------------------------

def load_tasks():
    """Load tasks from the text file into a list of dictionaries.

    Returns an empty list if the file doesn't exist yet (first run),
    and skips/reports any corrupted lines instead of crashing.
    """
    tasks = []

    if not os.path.exists(DATA_FILE):
        # Not an error -- just means this is the first time the app runs.
        return tasks

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                line = line.strip()
                if not line:
                    continue  # skip blank lines

                parts = line.split("|", maxsplit=2)
                if len(parts) != 3:
                    print(f"⚠️  Skipping corrupted line {line_number} in {DATA_FILE}.")
                    continue

                task_id_str, status, title = parts
                try:
                    task_id = int(task_id_str)
                except ValueError:
                    print(f"⚠️  Skipping line {line_number}: invalid task ID.")
                    continue

                tasks.append({"id": task_id, "status": status, "title": title})

    except PermissionError:
        print(f"⚠️  Permission denied when reading '{DATA_FILE}'. Starting with an empty task list.")
        return []
    except OSError as err:
        print(f"⚠️  Could not read '{DATA_FILE}': {err}. Starting with an empty task list.")
        return []

    return tasks


def save_tasks(tasks):
    """Save the full list of tasks to the text file.

    Returns True on success, False on failure (with an error message printed).
    """
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as file:
            for task in tasks:
                # Guard against '|' inside a title corrupting the format.
                safe_title = task["title"].replace("|", "/")
                file.write(f"{task['id']}|{task['status']}|{safe_title}\n")
        return True
    except PermissionError:
        print(f"⚠️  Permission denied when writing to '{DATA_FILE}'. Changes were NOT saved to disk.")
        return False
    except OSError as err:
        print(f"⚠️  Could not write to '{DATA_FILE}': {err}. Changes were NOT saved to disk.")
        return False


# ---------------------------------------------------------------------------
# CRUD Operations (In-Memory + Persisted)
# ---------------------------------------------------------------------------

def get_next_id(tasks):
    """Generate the next available task ID."""
    if not tasks:
        return 1
    return max(task["id"] for task in tasks) + 1


def add_task(tasks, title):
    """Create a new task and persist it."""
    new_task = {"id": get_next_id(tasks), "status": "pending", "title": title}
    tasks.append(new_task)
    if save_tasks(tasks):
        print(f"\n✅ Task {new_task['id']} added and saved: \"{title}\"")
    else:
        print(f"\n⚠️  Task added in memory, but saving to disk failed.")


def view_tasks(tasks):
    """Display all current tasks."""
    if not tasks:
        print("\nNo tasks found.")
        return

    print("\n" + "=" * 50)
    print(f"{'ID':<5}{'STATUS':<12}{'TITLE'}")
    print("-" * 50)
    for task in tasks:
        print(f"{task['id']:<5}{task['status']:<12}{task['title']}")
    print("=" * 50)


def find_task(tasks, task_id):
    """Return the task dict matching task_id, or None if not found."""
    for task in tasks:
        if task["id"] == task_id:
            return task
    return None


def update_task(tasks, task_id, new_title=None, new_status=None):
    """Update a task's title and/or status, then persist the change."""
    task = find_task(tasks, task_id)
    if task is None:
        print(f"\n⚠️  No task found with ID {task_id}.")
        return

    if new_title:
        task["title"] = new_title
    if new_status:
        task["status"] = new_status

    if save_tasks(tasks):
        print(f"\n✅ Task {task_id} updated and saved.")
    else:
        print(f"\n⚠️  Task updated in memory, but saving to disk failed.")


def delete_task(tasks, task_id):
    """Remove a task by ID and persist the change."""
    task = find_task(tasks, task_id)
    if task is None:
        print(f"\n⚠️  No task found with ID {task_id}.")
        return

    tasks.remove(task)
    if save_tasks(tasks):
        print(f"\n✅ Task {task_id} deleted and saved.")
    else:
        print(f"\n⚠️  Task deleted in memory, but saving to disk failed.")


# ---------------------------------------------------------------------------
# User Interface (Menu Loop)
# ---------------------------------------------------------------------------

def get_int_input(prompt):
    """Prompt until the user enters a valid integer."""
    while True:
        value = input(prompt).strip()
        try:
            return int(value)
        except ValueError:
            print("Please enter a valid whole number.")


def main():
    print("=" * 50)
    print("        TASK MANAGER (with file persistence)")
    print("=" * 50)

    tasks = load_tasks()
    print(f"Loaded {len(tasks)} task(s) from '{DATA_FILE}'.")

    while True:
        print("\nMenu:")
        print("1. View tasks")
        print("2. Add task")
        print("3. Update task")
        print("4. Delete task")
        print("5. Mark task complete")
        print("6. Exit")

        choice = input("Choose an option (1-6): ").strip()

        if choice == "1":
            view_tasks(tasks)

        elif choice == "2":
            title = input("Enter task title: ").strip()
            if title:
                add_task(tasks, title)
            else:
                print("\n⚠️  Task title cannot be empty.")

        elif choice == "3":
            view_tasks(tasks)
            if tasks:
                task_id = get_int_input("Enter the ID of the task to update: ")
                new_title = input("Enter new title (leave blank to keep unchanged): ").strip()
                update_task(tasks, task_id, new_title=new_title if new_title else None)

        elif choice == "4":
            view_tasks(tasks)
            if tasks:
                task_id = get_int_input("Enter the ID of the task to delete: ")
                delete_task(tasks, task_id)

        elif choice == "5":
            view_tasks(tasks)
            if tasks:
                task_id = get_int_input("Enter the ID of the task to mark complete: ")
                update_task(tasks, task_id, new_status="complete")

        elif choice == "6":
            print("\nAll changes are already saved. Goodbye!")
            break

        else:
            print("\nInvalid choice. Please choose a number from 1 to 6.")


if __name__ == "__main__":
    main()
