"""
Interactive Web Scraper
--------------------------
A simple, user-friendly web scraping program built with the
`requests` and `BeautifulSoup` libraries.

Two modes are provided:

1. QUOTES MODE
   Scrapes quotes, authors, and tags from http://quotes.toscrape.com,
   a website specifically built for practicing web scraping.

2. GENERIC MODE
   Lets the user enter ANY website URL and pulls back general,
   commonly-available data: page title, meta description, and all
   heading (h1/h2) text. This lets the program be tested against
   different websites, as requested in Step 4.

Notes on responsible scraping:
- A descriptive User-Agent header is sent with every request.
- robots.txt is not bypassed; this script only reads publicly
  rendered HTML that a normal browser would see.
- Requests use a timeout and are wrapped in error handling so the
  program fails gracefully on bad URLs, timeouts, or non-HTML pages.
"""

import requests
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Educational Web Scraping Demo)"
}
TIMEOUT = 10  # seconds


def fetch_page(url):
    """Fetch a URL and return a BeautifulSoup object, or None on failure."""
    try:
        response = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        response.raise_for_status()  # raises an error for 4xx/5xx responses
    except requests.exceptions.Timeout:
        print(f"\n⚠️  The request to {url} timed out. Please try again.")
        return None
    except requests.exceptions.ConnectionError:
        print(f"\n⚠️  Could not connect to {url}. Check the URL or your internet connection.")
        return None
    except requests.exceptions.HTTPError as err:
        print(f"\n⚠️  The website returned an error: {err}")
        return None
    except requests.exceptions.RequestException as err:
        print(f"\n⚠️  Something went wrong: {err}")
        return None

    return BeautifulSoup(response.text, "html.parser")


def scrape_quotes(max_pages=3):
    """Scrape quotes, authors, and tags from quotes.toscrape.com."""
    base_url = "http://quotes.toscrape.com"
    page_url = base_url
    all_quotes = []
    page_number = 1

    while page_url and page_number <= max_pages:
        soup = fetch_page(page_url)
        if soup is None:
            break

        quote_blocks = soup.find_all("div", class_="quote")
        if not quote_blocks:
            break

        for block in quote_blocks:
            text = block.find("span", class_="text").get_text(strip=True)
            author = block.find("small", class_="author").get_text(strip=True)
            tags = [tag.get_text(strip=True) for tag in block.find_all("a", class_="tag")]
            all_quotes.append({"text": text, "author": author, "tags": tags})

        # Follow the "Next" link if it exists, to demonstrate pagination
        next_link = soup.find("li", class_="next")
        if next_link:
            page_url = base_url + next_link.find("a")["href"]
            page_number += 1
        else:
            page_url = None

    return all_quotes


def display_quotes(quotes):
    """Present scraped quotes in a clean, readable format."""
    if not quotes:
        print("\nNo quotes were found.")
        return

    print(f"\nFound {len(quotes)} quote(s):\n")
    print("=" * 60)
    for i, quote in enumerate(quotes, start=1):
        print(f"{i}. \"{quote['text']}\"")
        print(f"   — {quote['author']}")
        if quote["tags"]:
            print(f"   Tags: {', '.join(quote['tags'])}")
        print("-" * 60)


def scrape_generic_page(url):
    """Scrape general-purpose data (title, description, headings) from any URL."""
    soup = fetch_page(url)
    if soup is None:
        return None

    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else "No title found"

    description_tag = soup.find("meta", attrs={"name": "description"})
    description = description_tag["content"].strip() if description_tag and description_tag.get("content") else "No meta description found"

    headings = []
    for level in ("h1", "h2"):
        for heading in soup.find_all(level):
            heading_text = heading.get_text(strip=True)
            if heading_text:
                headings.append(f"[{level.upper()}] {heading_text}")

    return {"title": title, "description": description, "headings": headings}


def display_generic_result(url, result):
    """Present the generic scrape result in a clean, readable format."""
    if result is None:
        return

    print("\n" + "=" * 60)
    print(f"RESULTS FOR: {url}")
    print("=" * 60)
    print(f"Page Title:\n  {result['title']}\n")
    print(f"Meta Description:\n  {result['description']}\n")

    if result["headings"]:
        print(f"Headings found ({len(result['headings'])}):")
        for heading in result["headings"][:10]:  # cap output for readability
            print(f"  - {heading}")
        if len(result["headings"]) > 10:
            print(f"  ... and {len(result['headings']) - 10} more")
    else:
        print("No headings (h1/h2) found on this page.")
    print("=" * 60)


def get_menu_choice():
    """Display the main menu and get a validated choice from the user."""
    print("\nWhat would you like to do?")
    print("1. Scrape quotes from quotes.toscrape.com")
    print("2. Scrape a website of your choice (title, description, headings)")
    print("3. Exit")

    while True:
        choice = input("Enter 1, 2, or 3: ").strip()
        if choice in ("1", "2", "3"):
            return choice
        print("Invalid choice. Please enter 1, 2, or 3.")


def main():
    print("=" * 60)
    print("            INTERACTIVE WEB SCRAPER")
    print("=" * 60)

    while True:
        choice = get_menu_choice()

        if choice == "1":
            print("\nFetching quotes... please wait.")
            quotes = scrape_quotes(max_pages=3)
            display_quotes(quotes)

        elif choice == "2":
            url = input("\nEnter the full URL to scrape (e.g., https://example.com): ").strip()
            if not url.startswith(("http://", "https://")):
                url = "https://" + url
            print(f"\nFetching {url} ... please wait.")
            result = scrape_generic_page(url)
            display_generic_result(url, result)

        elif choice == "3":
            print("\nGoodbye!")
            break

        again = input("\nReturn to the main menu? (y/n): ").strip().lower()
        if again != "y":
            print("\nGoodbye!")
            break


if __name__ == "__main__":
    main()
