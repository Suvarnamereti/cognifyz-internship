"""
Number Guessing Game
---------------------
A simple text-based game that demonstrates the use of conditional
statements (if / elif / else) to control game flow.

Rules:
1. The computer picks a random number between 1 and 100.
2. The player has a limited number of attempts to guess it.
3. After each guess, the game tells the player whether to guess
   higher or lower.
4. The game ends when the player guesses correctly or runs out
   of attempts.
"""

import random


def get_difficulty():
    """Ask the player to choose a difficulty, which sets the number of attempts."""
    print("Choose a difficulty level:")
    print("1. Easy   (10 attempts)")
    print("2. Medium (6 attempts)")
    print("3. Hard   (3 attempts)")

    choice = input("Enter 1, 2, or 3: ").strip()

    # Conditional logic to map choice -> number of attempts
    if choice == "1":
        return 10
    elif choice == "2":
        return 6
    elif choice == "3":
        return 3
    else:
        print("Invalid choice, defaulting to Medium (6 attempts).\n")
        return 6


def play_round():
    """Play a single round of the guessing game."""
    secret_number = random.randint(1, 100)
    attempts_left = get_difficulty()
    guessed_correctly = False

    print("\nI'm thinking of a number between 1 and 100.")
    print(f"You have {attempts_left} attempts. Good luck!\n")

    while attempts_left > 0:
        guess_input = input(f"Attempts left: {attempts_left}. Enter your guess: ").strip()

        # Validate input is a number
        if not guess_input.isdigit():
            print("Please enter a valid whole number.\n")
            continue

        guess = int(guess_input)

        # Core game logic using conditional statements
        if guess < 1 or guess > 100:
            print("Your guess must be between 1 and 100.\n")
        elif guess == secret_number:
            print(f"\n🎉 Correct! The number was {secret_number}.")
            guessed_correctly = True
            break
        elif guess < secret_number:
            print("Too low! Try a higher number.\n")
            attempts_left -= 1
        else:  # guess > secret_number
            print("Too high! Try a lower number.\n")
            attempts_left -= 1

    if not guessed_correctly:
        print(f"\n💀 Out of attempts! The number was {secret_number}.")

    return guessed_correctly


def main():
    print("=" * 40)
    print("   WELCOME TO THE NUMBER GUESSING GAME")
    print("=" * 40)

    wins = 0
    rounds_played = 0

    while True:
        played_round_result = play_round()
        rounds_played += 1
        if played_round_result:
            wins += 1

        print(f"\nScore: {wins} win(s) out of {rounds_played} round(s) played.")

        play_again = input("\nPlay again? (y/n): ").strip().lower()

        # Conditional to control whether the game loop continues
        if play_again == "y":
            print("\n" + "-" * 40 + "\n")
            continue
        elif play_again == "n":
            print("\nThanks for playing! Goodbye.")
            break
        else:
            print("Invalid input, exiting the game.")
            break


if __name__ == "__main__":
    main()
